-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 12-Fev-2023 às 21:18
-- Versão do servidor: 10.4.22-MariaDB
-- versão do PHP: 8.0.14

START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `mydb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cofins`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "cofins" ;

--
-- RELACIONAMENTOS PARA TABELAS `cofins`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `conta`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "conta" ;

--
-- RELACIONAMENTOS PARA TABELAS `conta`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `empresa`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "empresa" ;

--
-- RELACIONAMENTOS PARA TABELAS `empresa`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `endereco`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "endereco" ;

--
-- RELACIONAMENTOS PARA TABELAS `endereco`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `financeiro`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "financeiro" ;

--
-- RELACIONAMENTOS PARA TABELAS `financeiro`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `financeiro/cc`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "financeiro/cc" ;

--
-- RELACIONAMENTOS PARA TABELAS `financeiro/cc`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `gradex`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "gradex" ;

--
-- RELACIONAMENTOS PARA TABELAS `gradex`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `gradey`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "gradey" ;

--
-- RELACIONAMENTOS PARA TABELAS `gradey`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `grupo`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "grupo" ;

--
-- RELACIONAMENTOS PARA TABELAS `grupo`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `grupousuario`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "grupousuario" ;

--
-- RELACIONAMENTOS PARA TABELAS `grupousuario`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `grupo_tributario`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "grupo_tributario" ;

--
-- RELACIONAMENTOS PARA TABELAS `grupo_tributario`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `ipi`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "ipi" ;

--
-- RELACIONAMENTOS PARA TABELAS `ipi`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `itemmovimento`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "itemmovimento" ;

--
-- RELACIONAMENTOS PARA TABELAS `itemmovimento`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `itemservico`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "itemservico" ;

--
-- RELACIONAMENTOS PARA TABELAS `itemservico`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `localizacao`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "localizacao" ;

--
-- RELACIONAMENTOS PARA TABELAS `localizacao`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `movimento`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "movimento" ;

--
-- RELACIONAMENTOS PARA TABELAS `movimento`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `movimentoparcela`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "movimentoparcela" ;

--
-- RELACIONAMENTOS PARA TABELAS `movimentoparcela`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `movimento_conta`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "movimento_conta" ;

--
-- RELACIONAMENTOS PARA TABELAS `movimento_conta`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `nota`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "nota" ;

--
-- RELACIONAMENTOS PARA TABELAS `nota`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `notaitem`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "notaitem" ;

--
-- RELACIONAMENTOS PARA TABELAS `notaitem`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `operacao`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "operacao" ;

--
-- RELACIONAMENTOS PARA TABELAS `operacao`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `operacao_fiscal`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "operacao_fiscal" ;

--
-- RELACIONAMENTOS PARA TABELAS `operacao_fiscal`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `permissao`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "permissao" ;

--
-- RELACIONAMENTOS PARA TABELAS `permissao`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoa`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "pessoa" ;

--
-- RELACIONAMENTOS PARA TABELAS `pessoa`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `pis`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "pis" ;

--
-- RELACIONAMENTOS PARA TABELAS `pis`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `planodecontas`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "planodecontas" ;

--
-- RELACIONAMENTOS PARA TABELAS `planodecontas`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "produto" ;

--
-- RELACIONAMENTOS PARA TABELAS `produto`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtograde`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "produtograde" ;

--
-- RELACIONAMENTOS PARA TABELAS `produtograde`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `promocao`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "promocao" ;

--
-- RELACIONAMENTOS PARA TABELAS `promocao`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `servico`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "servico" ;

--
-- RELACIONAMENTOS PARA TABELAS `servico`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `subgrupo`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "subgrupo" ;

--
-- RELACIONAMENTOS PARA TABELAS `subgrupo`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `telas`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "telas" ;

--
-- RELACIONAMENTOS PARA TABELAS `telas`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tpendereco`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "tpendereco" ;

--
-- RELACIONAMENTOS PARA TABELAS `tpendereco`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tpfinanceiro`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "tpfinanceiro" ;

--
-- RELACIONAMENTOS PARA TABELAS `tpfinanceiro`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tpmovimento`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "tpmovimento" ;

--
-- RELACIONAMENTOS PARA TABELAS `tpmovimento`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tppagamento`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "tppagamento" ;

--
-- RELACIONAMENTOS PARA TABELAS `tppagamento`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tppessoa`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "tppessoa" ;

--
-- RELACIONAMENTOS PARA TABELAS `tppessoa`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tppessoa_pessoa`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "tppessoa_pessoa" ;

--
-- RELACIONAMENTOS PARA TABELAS `tppessoa_pessoa`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tributacao`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "tributacao" ;

--
-- RELACIONAMENTOS PARA TABELAS `tributacao`:
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--
-- Criação: 12-Fev-2023 às 20:07
--

CREATE TABLE "usuario" ;

--
-- RELACIONAMENTOS PARA TABELAS `usuario`:
--
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
